#include<iostream>
#include<pthread.h>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <unistd.h>
#include <netinet/in.h>
#include <pthread.h>
#include "http_server.hh"
#include<queue>
using namespace std;


void* startR(void* arg) {
    sleep(10);
    printf("Thread created\n");
}
int main() {
    int n;
    pthread_t t1;
    n = pthread_create(&t1, NULL, startR, NULL);
    printf("First %d\n", n);
    n = pthread_create(&t1, NULL, startR, NULL);
    printf("First %d\n", n);
}