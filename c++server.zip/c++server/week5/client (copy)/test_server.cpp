/* run using ./server <port> */

#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <unistd.h>
#include <netinet/in.h>
#include <pthread.h>
#include "http_server.hh"
#include <queue>
#include <signal.h>
#include <sys/types.h>

#define BUFFER_SIZE 1024
#define NUM_OF_WORKERS 50
#define QUEUE_SIZE 50
pthread_t workerThreads[NUM_OF_WORKERS];
pthread_mutex_t lock; // lock var
pthread_cond_t empty_con;  // empty_con var
pthread_cond_t full_con; // empty_con var
int terminated = 0;

//SHARED RESOURCES
queue<int> fdTasks;

void error(char *msg) {
    perror(msg);
}


void *startRoutine(void *args) {
    while (1) {
        // if (terminated == 1) {
        //     pthread_exit(NULL);
        // }

        // acquire lock and check conditions
        pthread_mutex_lock(&lock);
        while (fdTasks.empty()) {
            if (terminated == 1) {
                pthread_mutex_unlock(&lock);
                pthread_exit(NULL);
            }
            pthread_cond_wait(&empty_con, &lock);
        }
        int fd = fdTasks.front();
        fdTasks.pop();
        pthread_cond_signal(&full_con);
        pthread_mutex_unlock(&lock);

        ssize_t n;
        char buffer[BUFFER_SIZE];
        bzero(buffer, BUFFER_SIZE);

        n = read(fd, buffer, BUFFER_SIZE - 1);
        if (n == 0) {
            error("Connection closed by client");
        } else if (n < 0) {
            error("ERROR reading from socket");
        } else {
            HTTP_Response *response = handle_request(buffer);
            string responseString = response->get_string();

            /* send reply to client */
            n = write(fd, responseString.c_str(), responseString.length());
            if (n <= 0) {
                error("ERROR writing to socket");
            }
            delete response;
        }
        close(fd);
        
        if (terminated == 1) {
            break;
        }
    }
    pthread_exit(NULL);
}

void signalHandler(int num) {
    terminated = 1;
    pthread_cond_signal(&empty_con);
    for (int i = 0; i < NUM_OF_WORKERS;  i++) {
        int t = pthread_join(workerThreads[i], NULL);
        if (t == 0) {
            printf("Thread killed %d %ld\n", i, workerThreads[i]);
            // pthread_cancel(workerThreads[i]);
            // pthread_detach(workerThreads[i]);
        }
    }
    
    pthread_mutex_destroy(&lock); // destroy mutex  when exited
    exit(0);
}

int main(int argc, char* argv[]) {
    int sockfd, newsockfd, portno;
    socklen_t clilen;
    struct sockaddr_in serv_addr, cli_addr;
    clilen = sizeof(cli_addr);
    pthread_mutex_init(&lock, NULL);
    pthread_cond_init(&empty_con, NULL);
    int index = 0;
    signal(SIGINT, signalHandler);

    if (argc < 2) {
        fprintf(stderr, "ERROR, no port provided\n");
        exit(EXIT_FAILURE);
    }

    /* create socket */
    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd < 0) {
        error("ERROR opening socket");
        exit(EXIT_FAILURE);
    }

    /* fill in port number to listen on. IP address can be anything (INADDR_ANY)
     */
    portno = atoi(argv[1]);
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_addr.s_addr = INADDR_ANY;
    serv_addr.sin_port = htons(portno);

    /* bind socket to this port number on this machine */
    if (bind(sockfd, (struct sockaddr *) &serv_addr, sizeof(serv_addr)) < 0) {
        error("ERROR on binding");
        exit(EXIT_FAILURE);
    }


    /* Create Worker thead Pool */
    for (int i = 0; i < NUM_OF_WORKERS; i++) {
        if (pthread_create(&workerThreads[i], NULL, startRoutine, NULL) < 0) {
            error("Error creating thread");
        }
    }
    /* listen for incoming connection requests */
    listen(sockfd, 5);


    while (1) {
        /* reset client address to zero */
        bzero((char*)&cli_addr, clilen);

        /* accept a new request, create a newsockfd */
        newsockfd = accept(sockfd, (struct sockaddr *) &cli_addr, &clilen);
        if (newsockfd < 0) {
            error("ERROR on accept");
            exit(EXIT_FAILURE);
        }

        pthread_mutex_lock(&lock); // prevent race on Queue
        while (fdTasks.size() >= QUEUE_SIZE) {
            pthread_cond_wait(&full_con, &lock);
        }
        fdTasks.push(newsockfd);
        pthread_cond_signal(&empty_con);
        pthread_mutex_unlock(&lock);
    }
   return 0;
}

