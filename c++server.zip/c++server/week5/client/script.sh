#!/usr/bin/bash
path="./load_gen"
port=$1

for user in {1..8800..500}
do
    cmd=$($path "localhost" $port $user 0.1 60) 
    echo $cmd
    echo $cmd >> stats.txt
done
