import csv
import matplotlib.pyplot as plt
import numpy as np

user_count = []
th_put = []
res_time = []

with open("stats.txt") as file:
    reader = csv.reader(file, delimiter=",")
    for row in reader:
        user_count.append(int(row[0]))
        th_put.append(int(row[1]))
        res_time.append(float(row[2]))

    plt.plot(user_count, th_put)
    plt.xlabel("No. of users")
    plt.ylabel("Throughput")
    plt.savefig("tput.png", bbox_inches="tight")
    plt.cla()
    plt.plot(user_count, res_time)
    plt.xlabel("No. of users")
    plt.ylabel("Avg. response time")
    plt.savefig("restime.png", bbox_inches="tight")
